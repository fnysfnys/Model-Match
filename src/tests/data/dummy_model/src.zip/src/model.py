import random, pickle
class Model:
    def __init__(self):
        self.data = None
    def predict(self, file):
        return {"Classification": "Benign",
                "Confidence": (random.uniform(0,1) * self.data)}
    def train(self):
        self.data = 1

my_model = Model()
my_model.train()

picklefile = open("model", 'wb')

pickle.dump(my_model, picklefile)

picklefile.close()